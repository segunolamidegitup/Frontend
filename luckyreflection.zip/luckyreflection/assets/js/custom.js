$(document).ready(function(){



/**
 01 DASHBOARD JS
  
*/

 
 

$('span.close').click(function(){

    //Landing Page
    $('.menu').css({"left":"-480px"});

    //Stake Dashboard
    $('.navigations').css({"display":"none"});
    $('.navigation-container').css({"height":"70px"});




});

// Hamburger

$('.hamburger').click(function(){

    //Landing Page
    $('.menu').css({"left":"0"});

    // Stake Dashboard
    // $('.navigations').css({"display":"block"});
    $('.navigations').css({"display":"block"});
    $('.navigation-container').css({"height":"100vh"});


});


 





/**
 02 HOMAGEPAGE JS
  
*/

// AOS JS
AOS.init();


/**
 03 HOMAGEPAGE JS
  
*/
// Accordion JS Homepage FAQs


 

    $(".card:first-child").find('.body').addClass("visible");
 

$(".card").each(function(a,b) {
    
    $(b).click(function(){
    
    
        if ($(b).hasClass('visible')==true) {
            
        }else{
            $('.card').find('.body').removeClass("visible");

            $(this).find('.body').addClass("visible");
        // $(".faq  .accordion").removeClass("active");
        // $(".faq  .accordion").parent().removeClass("dropped");
        // $(".faq  .accordion").parent().find(".panel").css({"display":"none"});
    
        // $(b).toggleClass("active");
        // $(b).parent().toggleClass("dropped");
        // $(b).parent().find(".panel").slideToggle();
    
    }
    
    });
    
    
    });

    });